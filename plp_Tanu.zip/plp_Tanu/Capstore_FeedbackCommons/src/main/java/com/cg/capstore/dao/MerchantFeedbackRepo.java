package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.capstore.beans.MerchantFeedbackCommon;



@Repository
public interface MerchantFeedbackRepo extends JpaRepository<MerchantFeedbackCommon, Integer>{

	public List<MerchantFeedbackCommon> findByStatus(String status);
	
	public List<MerchantFeedbackCommon> findAllByStatus(String status);
	
	public List<MerchantFeedbackCommon> findAllByStatusAndCustomerId(String status,String id);
	
	
	
}
