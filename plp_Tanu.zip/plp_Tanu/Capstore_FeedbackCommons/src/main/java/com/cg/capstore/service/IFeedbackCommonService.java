package com.cg.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.cg.capstore.beans.MerchantFeedbackCommon;
import com.cg.capstore.beans.Reply;



@Service
public interface IFeedbackCommonService {

	void generateRequest(MerchantFeedbackCommon feedback);

	List<MerchantFeedbackCommon> viewAllFeedbackRequests();
	
	void forwardToMerchant(int feedbackId);
	
	List<MerchantFeedbackCommon> viewMyFeedbacks(String merchantId);

	void sendResponseToAdmin(int feedback_id, Reply response);

	List<MerchantFeedbackCommon> viewAllResponses();

	void sendResponseToCustomer(int responseId);

	List<MerchantFeedbackCommon> showMyResponse(String cust_id);

	
}
