package com.cg.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class MerchantFeedbackCommon {

	@Id
	@Column(name="Feedback_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int FeedbackId;

	@Column(name="Customer_Id")
	private String customerId;
	
	

	@Column(name="Merchant_Id")
	private String merchantId;

	
	@Column(name="Feedback_Comment")
	private String feedbackComment;
	
	@Column(name="Response")
	private String response;
	
	@Column(name="Status")
	private String status;


	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getResponse() {
		return response;
	}

	public int getFeedbackId() {
		return FeedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		FeedbackId = feedbackId;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getFeedbackComment() {
		return feedbackComment;
	}

	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
		
	
}
