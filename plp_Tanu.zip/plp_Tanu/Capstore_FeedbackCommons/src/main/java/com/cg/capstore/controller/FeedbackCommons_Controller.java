package com.cg.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.beans.Feedback;
import com.cg.capstore.beans.MerchantFeedbackCommon;
import com.cg.capstore.beans.Reply;
import com.cg.capstore.service.IFeedbackCommonService;

@RestController
public class FeedbackCommons_Controller {
	
	
	@Autowired
	IFeedbackCommonService fservice;
	
	@RequestMapping(method=RequestMethod.POST,value="/giveFeedback")
	public String generateFeedbackRequest(@RequestBody MerchantFeedbackCommon feedback) {
	
		feedback.setResponse("");
		feedback.setStatus("Requested");
		fservice.generateRequest(feedback);
		return "Feedback Request added successfully";
		
		
	}
	
	@RequestMapping(value="/forwardToMerchant")
	public List<MerchantFeedbackCommon> viewAllFeedbackRequests(){
		
		return fservice.viewAllFeedbackRequests();
		
	}
	
	@RequestMapping(value="/forwardToMerchant/{fid}")
	public String forwardToMerchant(@PathVariable int fid) {
		
		fservice.forwardToMerchant(fid);
		return "Forwarded to Merchant";
	}

	@RequestMapping(value="/Merchant_MyFeedbacks/{merchantId}")
	public List<MerchantFeedbackCommon> viewMyFeedbacks(@PathVariable String merchantId,HttpServletRequest request){
		
		//String mr_id= (String) request.getAttribute("ID");		
		
		return fservice.viewMyFeedbacks(merchantId);
		
	}
	
	
	@RequestMapping(value="/sendReply/{fid}")
	public void sendReply(@RequestBody Reply response,@PathVariable int fid ,HttpServletRequest request) {
		
		
		fservice.sendResponseToAdmin(fid,response);
		
	}
	
	@RequestMapping(value="/forwardToCustomer")
	public List<MerchantFeedbackCommon> viewRepliedResponses(){
		
		return fservice.viewAllResponses();
		
	}

	@RequestMapping(value="/sendResponseToCustomer/{responseId}")
	public String sendResponseToCustomer(@PathVariable int responseId) {
		
		fservice.sendResponseToCustomer(responseId);
		return "Response sent back to customer";
		
	}
	
	
	@RequestMapping(value="/Customer_MyFeedbacks/{cust_id}")
	
	public List<MerchantFeedbackCommon> customerViewResponses(@PathVariable String cust_id,HttpServletRequest request){
		
		//String cust_id=(String)request.getAttribute("Id");
		
		return fservice.showMyResponse(cust_id);
		
	} 
	
}
