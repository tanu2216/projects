package com.cg.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoreFeedbackCommonsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreFeedbackCommonsApplication.class, args);
	}

}
