package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.capstore.beans.MerchantFeedbackCommon;
import com.cg.capstore.beans.Reply;
import com.cg.capstore.dao.MerchantFeedbackRepo;

@Service
public class FeedbackCommonServiceImpl implements IFeedbackCommonService {

	@Autowired
	MerchantFeedbackRepo frepo;
	
	@Override
	public void generateRequest(MerchantFeedbackCommon feedback) {
		
		frepo.save(feedback);
		
	}

	@Override
	public List<MerchantFeedbackCommon> viewAllFeedbackRequests() {
		
		return frepo.findByStatus("Requested");
		
	}
	
	@Override
	public void forwardToMerchant(int feedback_id) {
		
		MerchantFeedbackCommon temp=frepo.findById(feedback_id).get();
		temp.setStatus("Forwarded");
		frepo.save(temp);
		
		
	}

	@Override
	public List<MerchantFeedbackCommon> viewMyFeedbacks(String merchantId) {
		
		return frepo.findByStatus("Forwarded");
		
	}

	@Override
	public void sendResponseToAdmin(int feedback_id,Reply response) {
		
		MerchantFeedbackCommon temp=frepo.findById(feedback_id).get();
		temp.setResponse(response.getResponse());
		temp.setStatus("Replied");
		frepo.save(temp);
		
	}

	@Override
	public List<MerchantFeedbackCommon> viewAllResponses() {
		
		return frepo.findAllByStatus("Replied");
		
	}

	@Override
	public void	sendResponseToCustomer(int responseId) {
		
		MerchantFeedbackCommon temp=frepo.findById(responseId).get();
		temp.setStatus("Responded");
		frepo.save(temp);	
	}

	@Override
	public List<MerchantFeedbackCommon> showMyResponse(String cust_id) {

		return frepo.findAllByStatusAndCustomerId("Responded" ,cust_id);
		
	}
		
}

